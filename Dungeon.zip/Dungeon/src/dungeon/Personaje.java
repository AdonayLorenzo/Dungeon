package dungeon;
public class Personaje {
    int daño;
    int escudo;
    int hp;
    String nombre;
    public Personaje(String nombre, int daño, int escudo, int hp) {
        this.nombre = nombre;
        this.daño = daño;
        this.escudo = escudo;
        this.hp = hp;
    }
    
}
