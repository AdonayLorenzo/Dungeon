package dungeon;
public class Personaje {
    int daño;
    int escudo;
    int hp;
    String nombre;
    int habilidad;
    public Personaje(String nombre, int daño, int escudo, int hp, int habilidad) {
        this.nombre = nombre;
        this.daño = daño;
        this.escudo = escudo;
        this.hp = hp;
        this.habilidad = habilidad;
    }
    public int habilidad(int hab){
        switch(hab){
            case 1:
                this.daño += this.daño;
                return 1;
            case 2:
                this.daño+=this.escudo;
                return 2;
            case 3:
                this.hp+=this.hp+this.daño;
                return 3;
        }
        return 2;
    }
}
