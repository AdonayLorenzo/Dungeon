package dungeon;

import static dungeon.Enemigo.azar;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Dungeon {

    public static int azar(int a) {
        return (int) Math.floor(Math.random() * a);
    }

    public static void main(String[] args) throws IOException {
        boolean vivo = true;
        System.out.println("Bienvenido a Dungeon");
        System.out.println("Ponle nombre a tu personaje:");
        BufferedReader user = new BufferedReader(new InputStreamReader(System.in));
        String nombre = user.readLine();
        System.out.println("Selecciona tu clase inicial");
        System.out.println("1) Berserker: HP:3, Daño:5, Escudo:2, Habilidad Pasiva:Furia, Habilidad:Doble Ataque,");
        System.out.println("2) Guerrero: HP:3, Daño:3, Escudo:4, Habilidad Pasiva:Hemorragia, Habilidad:Golpe Escudo Espada.");
        System.out.println("3) Clerigo: HP:5, Daño:3, Escudo:2, Habilidad Pasiva: Pacifismo, Habilidad:Sobrecuracion.");
        System.out.println("4) Vampiro: HP:5, Daño:4, Escudo:1, Habilidad Pasiva: Chupasangre, Habilidad: desarmar.");
        System.out.println("5) Fantasma: HP:1, Daño:40, Escudo:0, Habilidad Pasiva: Etereo, Habilidad: Furia Fantasmal.");
        Personaje uno = new Personaje(nombre,3,3,3,2);
        int eleccion = Integer.parseInt(user.readLine());
        switch(eleccion){
            case 1:
                uno.hp=3; uno.daño=5; uno.escudo=2; uno.habilidad=1;
                break;
            case 2:
                uno.hp=3; uno.daño=3; uno.escudo=4;
                break;
            case 3:
                uno.hp=5; uno.daño=3; uno.escudo=2; uno.habilidad = 3;
                break;
            case 4:
                uno.hp=5; uno.daño=4; uno.escudo=1; uno.habilidad=4;
                break;
            case 5:
                uno.hp=1; uno.daño=40; uno.escudo=0; uno.habilidad=5; 
                break;
        }
        System.out.println("Tus stats acuales son: HP:" + uno.hp + "Daño:" + uno.daño + "Escudo:" + uno.escudo);
        System.out.println("Comencemos " + uno.nombre + "!!");
        System.out.println("Controles, 1 atacar, 2 defender, 3 usar habilidad o 1 si, 2 no");
        Enemigo enemy = new Enemigo(3, 3, 3);
        int contador = 0;
        int derrotado;
        int vida_inicial = enemy.vida;
        int daño_inicial = uno.daño;
        int dañoEnemigo = enemy.daño;
        int dañotemp = dañoEnemigo;
        int escudotemp = enemy.escudo;
        System.out.println("Ha aparecido un nuevo enemigo, sus stats son: hp:" + enemy.vida + " daño:" + enemy.daño + " escudo:" + enemy.escudo);
        int asesinatos = 0;
        while (vivo != false) {
            try {
                if(uno.habilidad == 5){
                    uno.hp = 1;
                }
                // Código que podría lanzar la excepción
                System.out.println("Haz tu eleccion");
                eleccion = Integer.parseInt(user.readLine());
                if (eleccion == 1) {
                    enemy.vida -= uno.daño;
                    System.out.println("Salud actual del enemigo: " + enemy.vida);
                    uno.daño = daño_inicial;
                    contador--;
                if (uno.habilidad==4){
                    if(uno.hp<=daño_inicial+3){
                    uno.hp+=uno.daño;
                    System.out.println("Te has curado "+uno.daño+" por chupasangre, vida actual "+uno.hp+".");
                    }else{
                        System.out.println("Te has empachado, no puedes curarte aún");
                    }
                }
                }
                if (eleccion == 2) {
                    enemy.daño -= uno.escudo;
                    if (enemy.daño < 0) {
                        enemy.daño = 0;
                    }
                    uno.daño = daño_inicial;
                    System.out.println("El enemigo te hace " + enemy.daño + " de daño");
                    contador--;
                }
                if (eleccion == 3){
                    if(contador<=0){
                    if(uno.habilidad==1){
                        enemy.vida-=uno.daño+daño_inicial;
                        uno.daño=daño_inicial;
                        System.out.println("Atacas salvajemente a tu enemigo dejandolo a "+enemy.vida+" de vida.");
                        contador+=2;
                    }
                    if(uno.habilidad==2){
                        enemy.vida-=uno.daño+uno.escudo;
                        uno.daño=daño_inicial;
                        System.out.println("Atacas al enemigo con tu espada y escudo dejandolo a "+enemy.vida+" de vida.");
                        contador+=2;
                    }
                    if(uno.habilidad==3){
                        uno.hp+=daño_inicial;
                        System.out.println("Te has curado y ahora tienes "+uno.hp+" de vida.");
                        contador+=2;
                    }
                    if(uno.habilidad==4){
                        dañotemp = dañoEnemigo;
                        escudotemp = enemy.escudo;
                        enemy.daño=0;
                        enemy.escudo=0;
                        dañoEnemigo=0;
                        System.out.println("Le has despojado al enemigo su arma y escudo, no podra hacer daño ni cubrirse!!");
                        contador+=3;
                    }
                    if(uno.habilidad==5){
                        daño_inicial+=10;
                        uno.daño = daño_inicial;
                        System.out.println("Has elevado tu daño en 10 puntos, ahora es: "+uno.daño);
                        contador+=3;
                    }
                    }else{
                        contador--;
                        System.out.println("La habilidad esta en recarga, le faltan "+ contador + " turnos");
                    }
                }
                if (enemy.vida <= 0) {
                    asesinatos++;
                    if(uno.habilidad==1){
                        int z = azar(100);
                        if(z<=25){
                        daño_inicial+=2;
                        uno.daño = daño_inicial;
                        System.out.println("Tu daño a aumentado en 2, ahora es: "+uno.daño+".");
                        }else{
                            System.out.println("No has aprendido nada de esta batalla.");
                        }
                    }
                    uno.daño = daño_inicial;
                    int c = azar(60);
                    derrotado = enemy.derrotado(uno.daño, uno.hp, uno.escudo, c);

                    if (c >= 0 && c <= 20) {
                        eleccion = Integer.parseInt(user.readLine());
                        if (eleccion == 1) {
                            uno.hp = derrotado;

                            System.out.println("Has cambiado tu vida a " + uno.hp);
                        }
                    }
                    if (c >= 21 && c <= 40) {
                        eleccion = Integer.parseInt(user.readLine());
                        if (eleccion == 1) {
                            uno.escudo = derrotado;

                            System.out.println("Has cambiado tu escudo a " + uno.escudo);
                        }
                    }
                    if (c >= 41 && c <= 60) {
                        eleccion = Integer.parseInt(user.readLine());
                        if (eleccion == 1) {
                            uno.daño = derrotado;

                            System.out.println("Has cambiado tu daño a " + uno.daño);
                            daño_inicial = uno.daño;
                        }
                    }
                    dañoEnemigo= dañotemp;
                    enemy.escudo=escudotemp;
                    enemy.daño = dañoEnemigo;
                    enemy.daño += azar(3);
                    enemy.escudo += azar(3);
                    enemy.vida = vida_inicial + azar(3);
                    dañoEnemigo = enemy.daño;
                    dañotemp=dañoEnemigo;
                    escudotemp=enemy.escudo;
                    vida_inicial = enemy.vida;
                    if(uno.habilidad==3){
                        int z = azar(100);
                        if(z<=35){
                        dañoEnemigo-=(uno.escudo/2);
                        enemy.daño=dañoEnemigo;
                        System.out.println("Has pacificado al nuevo enemigo y su daño se redujo a "+enemy.daño+".");
                        }else{
                            System.out.println("No has conseguido pacificar al enemigo");
                        }
                    }
                    System.out.println("Ha aparecido un nuevo enemigo, sus stats son: hp:" + enemy.vida + " daño:" + enemy.daño + " escudo:" + enemy.escudo);
                } else {
                    eleccion = azar(2);
                    if (eleccion == 0) {
                        if(uno.habilidad == 5){
                            if(azar(100)<=5){
                                uno.hp -= enemy.daño;
                                System.out.println("El enemigo te ha alzanzado");
                                enemy.daño = dañoEnemigo;
                            }else{
                                System.out.println("El enemigo ha fallado el ataque");
                            }
                        }else{
                        uno.hp -= enemy.daño;
                        System.out.println("El enemigo ha atacado!! HP actuales: " + uno.hp);
                        enemy.daño = dañoEnemigo;
                        }
                    }
                    if (eleccion == 1) {
                        if (uno.daño >= 3) {
                            uno.daño -= enemy.escudo;
                        }
                        if (uno.daño < 0) {
                            uno.daño = 0;
                        }
                         enemy.daño = dañoEnemigo;
                        System.out.println("El enemigo se ha protegido!! Le haces " + uno.daño + " de daño.");
                    }
                }
                if (uno.hp <= 0) {
                    vivo = false;
                    System.out.println("Moriste");
                    System.out.println("Sobreviviste a "+asesinatos + "/50");
                }
                if(asesinatos == 50){
                    vivo = false;
                    System.out.println(uno.nombre+", lo has logrado, te has convertido en un guerrero legendario");
                    System.out.println("Todos contaran las historias de las leyendas a las que te has enfrentado");
                    System.out.println("Ahora "+uno.nombre+" transciende a un plano superior y conviertete en el ser supremo");
                    System.out.println("Adios, "+uno.nombre+"...");
                    System.out.println("Deseas continuar tu aventura?");
                    eleccion = Integer.parseInt(user.readLine());
                    if(eleccion == 1){
                        vivo = true;
                        asesinatos += 1;
                    }
                }
                if(uno.habilidad==2){
                    System.out.println("El enemigo ha sufrido "+daño_inicial/2+" de daño por hemorragia");
                    enemy.vida=enemy.vida-(daño_inicial/2);
                }
            } catch (NumberFormatException e) {
                // Manejo de la excepción
                System.out.println("Las opciones son, 1 atacar, 2 defender, 3 habilidad");
            }

        }
    }

}
