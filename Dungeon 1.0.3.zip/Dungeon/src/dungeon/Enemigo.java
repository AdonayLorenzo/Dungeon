package dungeon;
public class Enemigo {
    int daño;
    int escudo;
    int vida;
    
    public static int azar(int a){
        return (int)Math.floor(Math.random()*a);
    }
    
    public Enemigo(int daño, int escudo, int vida) {
        this.daño = daño;
        this.escudo = escudo;
        this.vida = vida;
    }
    public int derrotado(int dps, int hp, int escudo, int c){
        //Hacer que haya una probabilidad de que suelte un equipamiento con un ataque aleatorio
        int daño = dps;
        int vida = hp;
        int esc=escudo;
        if(c>=0 && c<=20){
            vida =hp + azar(4) +1;
            System.out.println("El enemigo ha soltado una gema con "+vida+" de vida, la pillas?");
            return vida;
        }
        if(c>=21 && c<=40){
            esc = escudo + azar(3) +1;
            System.out.println("El enemigo ha soltado un escudo con "+esc+" de escudo, la pillas?");
            return esc;
        }
        if(c>=41 && c<=60){
            daño = azar(3)+dps+1; 
            System.out.println("El enemigo ha soltado un arma con "+ daño + "de daño, la pillas?");
            return daño;
        } else{
            System.out.println("El enemigo no ha soltado nada");
            return dps;
        }
    }
}
